# -*- coding: utf-8 -*-
"""
Created on Tue Jan 14 22:28:46 2020

@author: MightyA
"""


import matplotlib.pyplot as plt
from skimage.io import imread, imshow
from skimage.transform import resize
import skimage.io as io
import glob

allow_pickle = True

from tempfile import TemporaryFile
outfile = TemporaryFile()


bilder = glob.glob('./bilder/*.png')

testb = []
transb = []

for img in bilder:
    testb.append(imread(img))
    

for p in testb:
    transb.append(resize(p, (255,255)))
    

for tb in transb:
    plt.imshow(tb)
    
    